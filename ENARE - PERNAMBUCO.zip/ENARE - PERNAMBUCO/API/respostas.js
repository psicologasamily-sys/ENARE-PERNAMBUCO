export default async function handler(request, response) {
  if (request.method !== "POST") {
    return response.status(405).json({ error: "Método não permitido" });
  }

  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;

  if (!url || !token) {
    return response.status(500).json({ error: "Variáveis do Upstash não configuradas." });
  }

  const {
    nome_completo,
    data_nascimento,
    nota,
    modalidade,
    programa_id,
    prioridade
  } = request.body || {};

  const nome = String(nome_completo || "").trim();
  const nascimento = String(data_nascimento || "").trim();
  const notaNum = Number(nota);
  const programa = Number(programa_id);
  const prioridadeNum = Number(prioridade);

  const programasValidos = [1, 2, 3, 4, 5, 6];

  if (
    nome.length < 5 ||
    nome.length > 120 ||
    !/^\d{4}-\d{2}-\d{2}$/.test(nascimento) ||
    !Number.isFinite(notaNum) ||
    notaNum < 0 ||
    notaNum > 100 ||
    !["AC", "PNP"].includes(modalidade) ||
    !programasValidos.includes(programa) ||
    ![1, 2, 3].includes(prioridadeNum)
  ) {
    return response.status(400).json({ error: "Dados inválidos." });
  }

  try {
    const currentResponse = await fetch(`${url}/get/enare_pe_ranking`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    const currentJson = await currentResponse.json();
    let respostas = [];

    if (currentJson.result) {
      try {
        respostas = JSON.parse(currentJson.result);
      } catch {
        respostas = [];
      }
    }

    const novaResposta = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
      nome_completo: nome,
      data_nascimento: nascimento,
      nota: notaNum,
      modalidade,
      programa_id: programa,
      prioridade: prioridadeNum,
      criado_em: new Date().toISOString()
    };

    respostas.push(novaResposta);

    await fetch(`${url}/set/enare_pe_ranking`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify([JSON.stringify(respostas)])
    });

    return response.status(200).json({ ok: true, resposta: novaResposta });
  } catch (error) {
    return response.status(500).json({ error: "Não foi possível salvar a resposta." });
  }
}
