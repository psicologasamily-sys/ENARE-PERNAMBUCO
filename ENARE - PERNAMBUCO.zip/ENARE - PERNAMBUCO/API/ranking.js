export default async function handler(request, response) {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;

  if (!url || !token) {
    return response.status(500).json({ error: "Variáveis do Upstash não configuradas." });
  }

  try {
    const redisResponse = await fetch(`${url}/get/enare_pe_ranking`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    const redisJson = await redisResponse.json();
    let respostas = [];

    if (redisJson.result) {
      try {
        respostas = JSON.parse(redisJson.result);
      } catch {
        respostas = [];
      }
    }

    respostas.sort((a, b) => Number(b.nota) - Number(a.nota));

    response.setHeader("Cache-Control", "no-store");
    return response.status(200).json(respostas);
  } catch (error) {
    return response.status(500).json({ error: "Não foi possível carregar o ranking." });
  }
}
